CREATE DATABASE IF NOT EXISTS `fusaviajes`;

USE `fusaviajes`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `urlimg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frase` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` VALUES (1,"EcoTurismo","2020-05-02 14:47:50","2020-08-03 13:28:42","1592768010Ecoturismo.webp","Un lugar increible"),
(2,"Monumentos","2020-05-02 14:47:50","2020-06-21 14:33:50","1592768030Monumentos.webp","Personajes que cobran vida"),
(3,"Murales","2020-06-12 09:53:13","2020-06-21 14:15:15","1592766915Murales.webp","Secretos entre paredes"),
(4,"Escenarios Culturales","2020-08-03 13:30:23","2020-08-03 13:30:44","Escenarios.webp","Donde el arte cobra vida");


DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `point` int(10) unsigned NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `img_comment` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `comments` VALUES (1,16,1,4,"casa","2020-07-03 08:50:39","2020-07-03 08:50:39",NULL),
(3,18,3,4,"No lo conocía.","2020-08-11 11:15:14","2020-08-11 11:15:14",NULL),
(4,22,26,4,"Llamativo","2020-08-12 08:52:30","2020-08-12 08:52:30",NULL),
(5,22,3,5,"Muy recomendable","2020-08-31 12:42:37","2020-08-31 12:42:37","1598895757IMG_20200716_083618.webp"),
(7,18,27,4,"Me gusta el lugar pero deberían arreglar el puente se esta empezando a deteriorar","2020-08-31 13:26:51","2020-08-31 13:26:51","1598898408IMG_20200831_132055_667.webp");


DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES (140,"2020_04_16_204312_create_usuarios_table",1),
(182,"2014_10_12_000000_create_users_table",2),
(183,"2014_10_12_100000_create_password_resets_table",2),
(184,"2019_08_19_000000_create_failed_jobs_table",2),
(185,"2020_04_09_180702_create_posts_table",2),
(186,"2020_04_09_214909_create_categories_table",2),
(187,"2020_04_12_195311_create_tags_table",2),
(188,"2020_04_12_200731_create_post_tag_table",2),
(189,"2020_04_19_202159_create_comments_table",2),
(190,"2020_05_02_180356_create_photos_table",2),
(191,"2020_05_02_193956_create_photocs_table",2);


DROP TABLE IF EXISTS `model_has_permissions`;

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `model_has_roles`;

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_roles` VALUES (1,"App\\User",1),
(2,"App\\User",2);


DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `permissions`;

CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `photos`;

CREATE TABLE `photos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `photos` VALUES (1,1,"/storage/hykBJ8zMKCjiWVYqviflEUVaTb0nQKP3KaLbA7un.webp","2020-05-02 14:51:51","2020-05-02 14:51:51"),
(2,2,"/storage/IPJxKcPLB3rU49zTAFqLNmbkqCjdWrvZy0dfvxJ1.webp","2020-05-02 15:00:02","2020-05-02 15:00:02"),
(3,3,"/storage/t8tuHMWt2PTGvhK5YupDu1MPuuf3qLa13vbbJ0bD.webp","2020-05-02 15:24:41","2020-05-02 15:24:41");


DROP TABLE IF EXISTS `post_tag`;

CREATE TABLE `post_tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `post_tag` VALUES (1,1,3,NULL,NULL),
(2,1,4,NULL,NULL),
(3,1,9,NULL,NULL),
(4,2,9,NULL,NULL),
(5,3,3,NULL,NULL),
(6,3,4,NULL,NULL),
(7,3,9,NULL,NULL),
(8,4,9,NULL,NULL),
(9,5,9,NULL,NULL),
(10,6,9,NULL,NULL),
(11,7,9,NULL,NULL),
(12,8,1,NULL,NULL),
(13,8,9,NULL,NULL),
(14,9,1,NULL,NULL),
(15,9,9,NULL,NULL),
(16,10,1,NULL,NULL),
(17,10,9,NULL,NULL),
(18,11,1,NULL,NULL),
(19,11,9,NULL,NULL),
(20,12,1,NULL,NULL),
(21,12,9,NULL,NULL),
(22,13,1,NULL,NULL),
(23,13,9,NULL,NULL),
(24,14,1,NULL,NULL),
(25,14,9,NULL,NULL),
(26,15,1,NULL,NULL),
(27,15,9,NULL,NULL),
(28,16,1,NULL,NULL),
(29,16,9,NULL,NULL),
(30,17,1,NULL,NULL),
(31,17,9,NULL,NULL),
(32,18,2,NULL,NULL),
(33,18,3,NULL,NULL),
(34,18,5,NULL,NULL),
(35,18,6,NULL,NULL),
(36,18,7,NULL,NULL),
(37,18,8,NULL,NULL),
(38,18,9,NULL,NULL),
(39,18,10,NULL,NULL),
(40,19,2,NULL,NULL),
(41,19,3,NULL,NULL),
(42,19,7,NULL,NULL),
(43,19,8,NULL,NULL),
(44,19,9,NULL,NULL),
(45,20,1,NULL,NULL),
(46,20,3,NULL,NULL),
(47,20,9,NULL,NULL),
(54,22,1,NULL,NULL),
(55,22,3,NULL,NULL),
(56,22,8,NULL,NULL),
(57,22,9,NULL,NULL),
(58,22,10,NULL,NULL);


DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `urlimg` text COLLATE utf8mb4_unicode_ci,
  `excerpt` mediumtext COLLATE utf8mb4_unicode_ci,
  `body` text COLLATE utf8mb4_unicode_ci,
  `published_at` timestamp NULL DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `point` float DEFAULT NULL,
  `vrimg_1` text COLLATE utf8mb4_unicode_ci,
  `vrimg_2` text COLLATE utf8mb4_unicode_ci,
  `vrimg_3` text COLLATE utf8mb4_unicode_ci,
  `vrimg_4` text COLLATE utf8mb4_unicode_ci,
  `vrimg_5` text COLLATE utf8mb4_unicode_ci,
  `vrimg_6` text COLLATE utf8mb4_unicode_ci,
  `color_vr` text COLLATE utf8mb4_unicode_ci,
  `pintor_vr` text COLLATE utf8mb4_unicode_ci,
  `ubicacion` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `escena_vr` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `posts` VALUES (1,"Monumento Lucho Herrera","monumento-lucho-herrera","1593620779Monumento_Lucho_Herrera.webp","El monumento lucho herrera es una estatua construida para conmemorar la hazaña deportiva realizada por el ciclista fusagasugueño Luis Alberto Herrera Herrera en la Vuelta España de 1987.","                  <p class=\"MsoNormal\"><span lang=\"ES-CO\">El monumento lucho herrera es una estatua\r\nconstruida para conmemorar la <b>hazaña deportiva</b> realizada por el ciclista\r\nfusagasugueño Luis Alberto Herrera Herrera en la Vuelta España de 1987, donde\r\nel escalador pudo coronarse <b>campeón</b> de este circuito. La estatua fue\r\ncreada en <b>diciembre del 2007</b>, cuenta con unas medidas de <b>6</b> metros\r\nde alto por <b>4</b> metros de ancho y se encuentra ubicada en la glorieta de\r\nla variante por la doble calzada Bogotá-Girardot.</span></p><p class=\"MsoNormal\"><br></p><p class=\"MsoNormal\"><iframe frameborder=\"0\" src=\"//www.youtube.com/embed/iAv92DTSozI\" width=\"100%\" height=\"360\" class=\"note-video-clip\"></iframe><span lang=\"ES-CO\"><o:p></o:p></span></p>\r\n                  ","2020-06-30 19:00:00",2,"2020-07-01 11:22:19","2020-07-01 11:26:19",4,"1593620779Monumento_Lucho_Herrera.webp","1593620779photo5100656058279504107.webp",NULL,NULL,NULL,NULL,"#badc58","Omar Clavijo","https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d248.6456988424333!2d-74.39099193094337!3d4.34881826759708!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x9eb952727d79ac12!2sMonumento%20Lucho%20Herrera!5e0!3m2!1ses!2sco!4v1592662222564!5m2!1ses!2sco","Luis Alberto Herrera, más conocido como Lucho Herrera y apodado \"El jardinerito de Fusagasugá\", fue el primer ciclista colombiano en ganar la vuelta a España, profesional entre los años de 1982 y 1992, durante los cuales consiguió 30 victorias en las diferentes etapas ciclísticas en las que participo. Lucho Herrera nació en Fusagasugá el 4 de mayo de 1961, fue pionero del ciclismo colombiano en Europa y su mayor exponente durante la década de 1980. Era un excelente escalador, como demuestran sus victorias en las clasificaciones de la montaña de las tres grandes vueltas, además de numerosas etapas y puestos de honor en las mismas, Ha sido, junto con el español Federico Martín Bahamontes, ganador de la montaña en las tres grandes vueltas europeas. (Guía Turística Fusagasugá 2017)","2_Escena"),
(2,"Monumento Jardinera","monumento-jardinera","Monumento_Jardinera.webp","Esta escultura representa a la mujer floricultura y campesina de Fusagasugá, está ubicada en la Cra.9 #10-1 junto a  la plaza principal de mercado desde el año 2003.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Esta escultura representa a la mujer <b>floricultura</b>\r\ny <b>campesina</b> de Fusagasugá, está ubicada en la <b>Cra.9 #10-1</b> junto\r\na&nbsp; la plaza principal de mercado desde el\r\naño 2003, está elaborada en <b>bronce</b> y sus medidas aproximadas son 3\r\nmetros de alto con 1.20 metros de ancho.<o:p></o:p></span></p>","2020-07-01 19:00:00",2,"2020-07-01 12:53:06","2020-07-01 13:04:39","4.3","Monumento_Jardinera.webp","1593626679photo5100656058279504103.webp","1593626679Monumento_Jardinera.webp",NULL,NULL,NULL,"#ffb142","Sofia Sánchez.","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d683.2618286880668!2d-74.36521944998115!3d4.341651150242952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f056794a0a37f%3A0x75a96485f8142c01!2sMonumento%20a%20la%20Jardinera!5e0!3m2!1ses!2sco!4v1592666251984!5m2!1ses!2sco",NULL,"1_Escena"),
(3,"Monumento Indio Sutagao","monumento-indio-sutagao","1593627096Monumento_Indio_Sutagao - copia.webp","Representación insignia de Fusagasugá, este monumento es el homenaje a los primeros ancestros que habitaron la ciudad, el majestuoso Indio Sutagao fue elaborado en el año de 1994.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Representación <b>insignia</b> de\r\nFusagasugá, este monumento es el <b>homenaje</b> a los primeros ancestros que\r\nhabitaron la ciudad, el majestuoso Indio <b>Sutagao</b> fue elaborado en el año\r\nde <b>1994</b>, cuenta con unas medidas aproximas de <b>5</b> metros de alto\r\ncon <b>2</b> metros de ancho y se encuentra ubicado en la Cl 24B antigua vía\r\npanamericana.<o:p></o:p></span></p>","2020-07-02 19:00:00",2,"2020-07-01 13:09:15","2020-07-01 13:11:36","4.3","1593627096Monumento_Indio_Sutagao.webp","1593627096IMG_20200604_095724.webp","1593627096Monumento_Sutagao.webp",NULL,NULL,NULL,"#badc58","Luis Enrique Suárez.","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.4223501553224!2d-74.37981148570663!3d4.331518245955255!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f049468ddbae7%3A0xebea04a5f8ed2ef0!2sMonumento%20al%20Indio%20Sutagao!5e0!3m2!1ses!2sco!4v1592666316640!5m2!1ses!2sco","Este monumento es un homenaje a la tribu indígena de los Sutagao, nombre que etimológicamente significa \"hijos del sol\", habitantes del territorio comprendido entre los ríos de Pasca y Sumapaz. Su naturaleza sedentaria les facilito la adaptación al clima y a los recursos de la zona, y fueron el resultado de la pluralidad de culturas que confluían en la región. (Guía Turística Fusagasugá 2017)","2_Escena"),
(4,"Monumento Rumba Criolla","monumento-rumba-criolla","1593627346Monumento_Rumba_Criolla - copia.webp","Elaborado en el año 2011, esta escultura enaltece el popular festival de la Rumba Criolla Fusagasugueña, que es llevado cada año en la ciudad.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Elaborado en el año <b>2011</b>, esta\r\nescultura enaltece el popular festival de la <b>Rumba Criolla</b>\r\nFusagasugueña, que es llevado cada año en la ciudad, la escultura con medidas\r\nde <b>3.20</b> metros de alto con <b>1.10</b> metros de ancho fue elaborada por\r\nSofia Sánchez y su inspiración fue la joven bailarina <b>Luz Emilse Moreno\r\nFierro </b>se encuentra ubicada en el barrio la Marsella, Dg. 16 junto a la\r\nbiblioteca municipal.<o:p></o:p></span></p>","2020-07-03 19:00:00",2,"2020-07-01 13:14:05","2020-07-01 13:15:46",4,"1593627346Monumento_Rumba_Criolla.webp","1593627346Monumento_Rumba_Criolla.webp",NULL,NULL,NULL,NULL,"#f6e58d","Sofia Sánchez.","https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15913.56996307328!2d-74.3631814!3d4.3371919!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x11f797a3e48ba26d!2sMonumento%20a%20la%20Rumba%20Criolla!5e0!3m2!1ses!2sco!4v1592666450480!5m2!1ses!2sco","Se encuentra ubicada en la Biblioteca Municipal María Aya, Fusagasugá, es una escultura en Homenaje a la Rumba Criolla Fusagasugueña, inspirada en la niña Luz Emilse Moreno Fierro, que a su corta edad demostró la grandeza del baile de la Rumba Criolla que se celebra, lamentablemente no está entre nosotros pero nos deja el legado de su sonrisa y baile. Su padre luchó varios años para lograr que su hija fuera recordada en lo que a ella más le gustaba: el baile, eso me conmovió mucho, y fui feliz de poder plasmar a una Emilse sonriente y bella. (Sofia Sánchez)","2_Escena"),
(5,"Monumento Emilio Sierra","monumento-emilio-sierra","1593627534Monumento_Emilio_Sierra - copia.webp","Emilio Sierra Baqueo nació en Fusagasugá el 15 de septiembre de 1891, sus mambos, merecumbés y uno que otro porro, lo hicieron inmortal, pero no tanto como lo hizo el ritmo que Sierra creó: La Rumba Criolla.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Elaborada en homenaje al <b>compositor</b> fusagasugueño\r\nde la <b>Rumba Criolla</b> Emilio Sierra Baquero, esta escultura se ubica en la\r\nplazoleta de los <b>músicos</b> con dirección Cl .8a Cra 7 cuenta con unas\r\nmedidas aproximadas de <b>2.30</b> metros de alto con <b>1</b> metro de ancho.<o:p></o:p></span></p>","2020-07-04 19:00:00",2,"2020-07-01 13:16:44","2020-07-01 13:18:54","3.5","1593627534Monumento_Emilio_Sierra.webp","1593627534Monumento_Emilio_Sierra.webp",NULL,NULL,NULL,NULL,"#fed330","Desconocido.","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.36393491243!2d-74.3645066857066!3d4.342610945868706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f71b2f8e1f%3A0xb3e401ba8103e7ec!2sCl.%208a%20%237-88%2C%20Fusagasug%C3%A1%2C%20Cundinamarca!5e0!3m2!1ses!2sco!4v1592669786544!5m2!1ses!2sco","Emilio Sierra Baqueo nació en Fusagasugá el 15 de septiembre de 1891, sus mambos, merecumbés y uno que otro porro, lo hicieron inmortal, pero no tanto como lo hizo el ritmo que Sierra creó: La Rumba Criolla. (Diario \"El Tiempo\"). Emilio Sierra compuso más de 100 canciones, en distintos ritmos tales como bambucos, pasillos, porros, rumbas criollas y boleros. Entre las más conocidas están \"Vivan los novios\", \"Adiós Guayabo\", \"Cariñito\", \"Atardeceres\", \"Amorcito Lindo\", \"La Reina de la Alegría\", \"Trago a los Músicos\" y \"Pin Pan Pun\".(Guía Turística Fusagasugá 2017)","2_Escena"),
(6,"Monumento Jorge Eliecer Gaitán","monumento-jorge-eliecer-gaitan","1593628315Monumento_Jorge_Eliecer_Gaitan-01 - copia.webp","“Yo no soy un hombre, soy un pueblo y el pueblo es mayor que sus dirigentes”.(Jorge Eliecer Gaitán)","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Construido por estudiantes de la escuela <b>General\r\nSantander</b> como homenaje al popular <b>político Jorge Eliecer Gaitán</b> asesinado\r\nel 4 de abril de 1948, este <b>monumento</b> fue instaurado el 9 de Abril del 2009\r\nen el barrio Gaitán con Cra 11 Cl. 2, cuenta con unas medidas aproximadas de <b>2</b>\r\nmetros de alto y <b>1 </b>metro de ancho.<o:p></o:p></span></p>","2020-07-05 19:00:00",2,"2020-07-01 13:20:24","2020-07-01 13:31:55",4,"1593628315Monumento_Jorge_Eliecer_Gaitan-01.webp","1593628315Monumento_Jorge_Eliecer_Gaitan-02.webp",NULL,NULL,NULL,NULL,"#FFC312","Alumnos de la Escuela General Santander.","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.3418742784356!2d-74.36529446321579!3d4.346792776499134!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04fa31d82ee9%3A0xe9358a6d7c116bea!2sCra.%2011%20%26%20Cl.%202%2C%20Fusagasug%C3%A1%2C%20Porta%20Bello%2C%20Fusagasug%C3%A1%2C%20Cundinamarca!5e0!3m2!1ses!2sco!4v1592668140066!5m2!1ses!2sco","Jorge Eliécer Gaitán Ayala fue un jurista, escritor, activista, orador y político nacionalista colombiano. Fue rector de la Universidad Libre de Colombia entre 1936 y 1939, de la cual, fue catedrático de Derecho Penal desde 1931 hasta su muerte. Fue alcalde de Bogotá en el año 1936, titular en dos ministerios (Educación en 1940 y Trabajo en 1944) y congresista durante varios períodos entre 1929 y 1948. También fue candidato presidencial disidente del Partido Liberal en las elecciones de 1946 y su posterior jefe único, además que iba a ser el candidato oficial del partido para las presidenciales de 1950. Gaitán se forjó una reputación como orador y defensor de causas populares, que consolidó gracias a sus intervenciones en el debate sobre la Masacre de las Bananeras de 1928. Su asesinato produjo enormes protestas populares inicialmente en Bogotá y luego a nivel nacional conocidas como el \"Bogotazo\", y el inicio de un periodo sangriento en la historia del país conocido como \'La Violencia\'.","2_Escena"),
(7,"Monumento Manuel Humberto Cárdenas Vélez","monumento-manuel-humberto-cardenas-velez","1593628484Monumento_Manuel_Cardenas.webp","Fusagasugá para todos: A ustedes mis agradecimientos por haberme aguantado tanto tiempo en la Alcaldía y quiero manifestarles que sin ustedes no habría sido posible llevar a cabo el plan de gobierno.(Manuel Humberto Cárdenas Vélez)","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Gracias por compartir conmigo dos años y\r\nmedio de gobierno y ojalá que el futuro les depare mucha suerte y mejores cosas\r\nen los gobiernos municipales... que Dios los bendiga , finalizó su último\r\ndiscurso.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">Elaborado como un <b>homenaje</b> en\r\nDiciembre del 2008, al asesinado ex alcalde fusagasugueño <b>Manuel Humberto\r\nCárdenas Vélez</b>, este monumento ubicado en <b>Cl 17 #11a-35</b>&nbsp; con medidas de <b>1.40</b> metros de alto y <b>75</b>\r\ncm de ancho, hace honor a una de las personas mas <b>representativas</b> que\r\ntuvo la ciudad, el cual fue un ferviente defensor de la <b>justicia</b> y la <b>seguridad</b>\r\nciudadana.&nbsp;<o:p></o:p></span></p>","2020-07-06 19:00:00",2,"2020-07-01 13:32:11","2020-07-01 13:34:44","4.5","1593628484Monumento_Manuel_Cardenas.webp","1593628484Monumento_Manuel_Humberto_Cardenas_Velez.webp",NULL,NULL,NULL,NULL,"#fed330","Desconocido.","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d994.5994339214127!2d-74.36653497085194!3d4.336195837069236!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f36a5d53e9%3A0xa38543aa13f0185c!2sCl.%2017%20%2311a-35%2011a%2C%20Fusagasug%C3%A1%2C%20Cundinamarca!5e0!3m2!1ses!2sco!4v1592670142338!5m2!1ses!2sco","Manuel Humberto Cárdenas, nació el 30 de Junio de 1963 tenía una gran afición por los caballos de paso, hizo la primaria y bachillerato en el Colegio Ricaurte, derecho en la Universidad Santo Tomás y un posgrado de ciencias políticas en la Universidad Javeriana. Entre los cargos desempeñados en Fusagasugá, su pueblo natal, había sido personero, contralor y secretario de gobierno. Fue condecorado en dos ocasiones por el Ejército y la Policía, como reconocimiento a su labor frente a los problemas de orden público en la ciudad.(El tiempo, 1994)","2_Escena"),
(8,"Mural Floral","mural-floral","1593628990Mural_Flores - copia.webp","El mural floral es una representación artística que enaltece los atributos florales que contiene la ciudad de Fusagasugá se encuentra ubicado en la Cl 6 #624 junto a la alcaldía municipal.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">El mural floral es una representación artística\r\nque enaltece los atributos <b>florales</b> que contiene la ciudad de Fusagasugá\r\nse encuentra ubicado en la <b>Cl 6 #624</b> junto a la alcaldía municipal, fue\r\nelaborado por el artista <b>GLEO</b> en el año de <b>2019</b>.<o:p></o:p></span></p>","2020-06-30 19:00:00",3,"2020-07-01 13:38:31","2020-07-01 13:43:10","4.1","1593628990Mural_Flores.webp","1593628990Mural_Flores_3.webp","1593628990Mural_Flores_2.webp",NULL,NULL,NULL,"#EA2027","GLEO","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.355610226273!2d-74.36227075718246!3d4.344189451745282!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f7785b3b25%3A0x69fd7f2d78923379!2sAlcald%C3%ADa%20Municipal%20De%20Fusagasug%C3%A1!5e0!3m2!1ses!2sco!4v1592669014213!5m2!1ses!2sco",NULL,"1_Escena"),
(9,"Mural Energía","mural-energia","1593629262Mural_Energia - copia.webp","Ubicado en la Cl6 #624 junto a la alcaldía municipal el mural energía es una representación de la cultura juvenil y vivaz que identifica a su población.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Ubicado en la <b>Cl6 #624 </b>junto a la alcaldía\r\nmunicipal el mural energía es una representación de la cultura juvenil y vivaz\r\nque identifica a su población, fue diseñado por <b>TONRA</b> en el <b>2020</b>.<o:p></o:p></span></p>","2020-07-01 19:00:00",3,"2020-07-01 13:46:16","2020-07-01 13:47:42","4.3","1593629262Mural_Energia.webp","1593629262Mural_Energia_2.webp","1593629262Mural_Energia_3.webp",NULL,NULL,NULL,"#00a8ff","TONRA","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.355610226273!2d-74.36227075718246!3d4.344189451745282!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f7785b3b25%3A0x69fd7f2d78923379!2sAlcald%C3%ADa%20Municipal%20De%20Fusagasug%C3%A1!5e0!3m2!1ses!2sco!4v1592669014213!5m2!1ses!2sco",NULL,"1_Escena"),
(10,"Mural Paramo","mural-paramo","1593629370PANO_20200625_081702-02.webp","Una expresión artística para enaltecer la fauna y flora que habita en el páramo de Sumapaz.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Una expresión artística para enaltecer la <b>fauna</b>\r\ny <b>flora</b> que habita en el páramo de <b>Sumapaz</b>, este mural se\r\nencuentra ubicado en la Cra. <b>6 #11-70</b> y busca poder enviar un mensaje al\r\ntranseúnte que lo ve, sobre la protección y preservación de estas zonas <b>naturales</b>\r\ndonde habitan estos <b>animales</b> en vía de extinción.<o:p></o:p></span></p>","2020-07-02 19:00:00",3,"2020-07-01 13:48:00","2020-07-01 13:49:30","4.5","1593629370PANO_20200625_081702-01.webp","1593629370PANO_20200625_081702-03.webp","1593629370PANO_20200625_081702-05.webp",NULL,NULL,NULL,"#130f40","Desconocido.","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.378566266907!2d-74.3636128229606!3d4.339835196861164!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f67cfa114b%3A0x6b5ade755a41d272!2sCra.%206%20%2311-70%2C%20Fusagasug%C3%A1%2C%20Cundinamarca!5e0!3m2!1ses!2sco!4v1592670806261!5m2!1ses!2sco",NULL,"1_Escena"),
(11,"Mural Belleza","mural-belleza","1593629512PANO_20200625_082322-02.webp","Mural representativo que busca honrar  la belleza de la mujer fusagasugueña.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Mural representativo que busca honrar &nbsp;la <b>belleza</b> de la mujer fusagasugueña, fue\r\ndiseñado por la artista <b>GLAEN</b> en el <b>2019</b> y se encuentra ubicado\r\nen <b>la Cl. 11 #560</b>.<o:p></o:p></span></p>","2020-07-03 19:00:00",3,"2020-07-01 13:50:35","2020-07-01 13:51:52","4.2","1593629512PANO_20200625_082322-01.webp","1593629512PANO_20200625_082322-03.webp","1593629512PANO_20200625_082322-04.webp",NULL,NULL,NULL,"#f6e58d","GLEAN","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.378048015218!2d-74.36492348570663!3d4.33993354588963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f69ea9a13b%3A0xd5abf76620426ee7!2sAutopartes%20la%20Kia!5e0!3m2!1ses!2sco!4v1593616637668!5m2!1ses!2sco",NULL,"1_Escena"),
(12,"Mural Multicolor","mural-multicolor","1593629611PANO_20200625_082451-02.webp","Trasmitir un mundo diverso y nuevo, donde posiblemente su autor SUKU quiso exponer algunos de sus pensamientos contemporáneos.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Ubicado en la <b>Cl. 11 #560</b> este mural\r\nlleno de colores vivos y atractivos, intenta trasmitir un mundo <b>diverso</b>\r\ny nuevo, donde posiblemente su autor <b>SUKU</b> quiso exponer algunos de sus\r\npensamientos contemporáneos.<o:p></o:p></span></p>","2020-07-04 19:00:00",3,"2020-07-01 13:52:04","2020-07-01 13:53:31",4,"1593629611PANO_20200625_082451-01.webp","1593629611PANO_20200625_082451-05.webp","1593629611PANO_20200625_082451-03.webp",NULL,NULL,NULL,"#ff7979","SUKU","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.378048015218!2d-74.36492348570663!3d4.33993354588963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f69ea9a13b%3A0xd5abf76620426ee7!2sAutopartes%20la%20Kia!5e0!3m2!1ses!2sco!4v1593616637668!5m2!1ses!2sco",NULL,"1_Escena"),
(13,"Mural Cool","mural-cool","1593629693PANO_20200625_082125-02.webp","Inspirado en el arte urbano y en la cultura callejera el artista AVLN nos presenta su obra artística.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Inspirado en el <b>arte urbano</b> y en la\r\ncultura callejera el artista <b>AVLN</b> nos presenta su obra artística en la <b>Cl.\r\n11 #560</b>, un mural llamativo donde la mezcla de colores <b>juegan</b> un\r\npapel importante.<o:p></o:p></span></p>","2020-07-05 19:00:00",3,"2020-07-01 13:53:46","2020-07-01 13:54:53","4.6","1593629693PANO_20200625_082125-01.webp","1593629693PANO_20200625_082125-01-01.webp","1593629693PANO_20200625_082125-01-02.webp",NULL,NULL,NULL,"#ED4C67","AVLN","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.378048015218!2d-74.36492348570663!3d4.33993354588963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f69ea9a13b%3A0xd5abf76620426ee7!2sAutopartes%20la%20Kia!5e0!3m2!1ses!2sco!4v1593616637668!5m2!1ses!2sco",NULL,"1_Escena"),
(14,"Mural Noche","mural-noche","1593629839PANO_20200625_082902-01-01.webp","Ubicado en la Cl. 9 #11 junto al tradicional Puente del Águila, esta obra de arte transmite la belleza de la mujer fusagasugueña.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Mural ubicado en la <b>Cl. 9 #11</b> junto\r\nal tradicional Puente de el Águila, esta obra de arte <b>transmite</b> la <b>belleza</b>\r\nde la mujer fusagasugueña, la cual no necesita del día para <b>deslumbrar</b>.<o:p></o:p></span></p>","2020-07-06 19:00:00",3,"2020-07-01 13:56:01","2020-07-01 13:57:19","4.2","1593629839PANO_20200625_082902-01.webp","1593629839PANO_20200625_082902-01-03.webp","1593629839PANO_20200625_082902-01-02.webp",NULL,NULL,NULL,"#130f40","Desconocido.","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.378048015218!2d-74.36492348570663!3d4.33993354588963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f41ae4eb35%3A0x68a0d19e16acdd7d!2sPuente%20el%20%C3%81guila!5e0!3m2!1ses!2sco!4v1593616726064!5m2!1ses!2sco",NULL,"1_Escena"),
(15,"Mural Sueña","mural-suena","1593629929PANO_20200625_082807-01-01.webp","Este mural presenta un mundo divergente, realmente sacada de un cuento de hadas.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Elaborado en una <b>colaboración</b> por\r\nparte de los artistas <b>SUKU</b> y <b>SANTANA</b>, este mural presenta un\r\nmundo <b>divergente</b>, realmente sacada de un cuento de hadas, ubicado en la <b>Cl.\r\n9 #11</b>.<o:p></o:p></span></p>","2020-07-07 19:00:00",3,"2020-07-01 13:57:32","2020-07-01 13:58:49","4.2","1593629929PANO_20200625_082807-01.webp","1593629929PANO_20200625_082807-01-02.webp","1593629929PANO_20200625_082807-01-03.webp",NULL,NULL,NULL,"#ffc048","SUKU & SANTANA","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.378048015218!2d-74.36492348570663!3d4.33993354588963!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f41ae4eb35%3A0x68a0d19e16acdd7d!2sPuente%20el%20%C3%81guila!5e0!3m2!1ses!2sco!4v1593616726064!5m2!1ses!2sco",NULL,"1_Escena"),
(16,"Mural Raíces","mural-raices","1593630048Mural_Raices - copia.webp","Inspirado en la tradición de los ancestros Sutagaos, los cuales fueron los primeros habitantes de la ciudad de Fusagasugá.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Inspirado en la tradición de los ancestros <b>Sutagaos</b>,\r\nlos cuales fueron los primeros habitantes de la ciudad de Fusagasugá, el mural raíces\r\nplasma a la mujer <b>combativa</b> acompañada de colores y formas geométricas ancestrales\r\npopulares de la cultura <b>muisca</b>, esta expresión de arte fue elaborada en\r\nel <b>2019</b> por <b>SALLALLL</b> y se encuentra ubicada en la <b>Cra 6#11-70</b>.&nbsp;<o:p></o:p></span></p>","2020-07-08 19:00:00",3,"2020-07-01 13:59:07","2020-07-01 14:00:48",4,"1593630048Mural_Raices.webp","1593630048Mural_Raices_2.webp","1593630048Mural_Raices_3.webp",NULL,NULL,NULL,"#22a6b3","SALLALLL","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.378566266907!2d-74.3636128229606!3d4.339835196861164!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f67cfa114b%3A0x6b5ade755a41d272!2sCra.%206%20%2311-70%2C%20Fusagasug%C3%A1%2C%20Cundinamarca!5e0!3m2!1ses!2sco!4v1592670806261!5m2!1ses!2sco",NULL,"1_Escena"),
(17,"Mural Salvaje","mural-salvaje","1593630239Mural_Salvaje.webp","Como muestra de la riqueza natural que enorgullece a la región andina, este mural representa la fauna y flora que cubre gran parte de la región del Sumapaz.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">Como muestra de la <b>riqueza</b> natural\r\nque enorgullece a la región <b>andina</b>, este mural representa la <b>fauna</b>\r\ny <b>flora</b> que cubre gran parte de la región del <b>Sumapaz</b>, se\r\nencuentra ubicado en la <b>Cra. 6#11-70</b> y fue realizado por <b>MACONDIAN</b>\r\nen el <b>2019</b>.<o:p></o:p></span></p>","2020-07-08 19:00:00",3,"2020-07-01 14:02:04","2020-07-01 14:03:59","4.4","1593630239Mural_Salvaje.webp","1593630239Mural_Salvaje_2.webp","1593630239Mural_Salvaje_3.webp",NULL,NULL,NULL,"#009432","MACONDIAN.","https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.378566266907!2d-74.3636128229606!3d4.339835196861164!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f67cfa114b%3A0x6b5ade755a41d272!2sCra.%206%20%2311-70%2C%20Fusagasug%C3%A1%2C%20Cundinamarca!5e0!3m2!1ses!2sco!4v1592670806261!5m2!1ses!2sco",NULL,"1_Escena"),
(18,"Parque Natural San Rafael","parque-natural-san-rafael","1593630670MVIMG_20200611_120801.webp","El parque natural San Rafael establecido como reserva ecológica el 28 de mayo del 2004 por acuerdo municipal, se encuentra ubicada entre el corregimiento de la Aguadita y la vereda San Rafael, cuenta con atractivos naturales como su riqueza hídrica, paisajística y floral.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">El parque natural San Rafael establecido como\r\nreserva ecológica el <b>28</b> de mayo del <b>2004</b> por acuerdo municipal, se\r\nencuentra ubicada entre el corregimiento de la <b>Aguadita</b> y la vereda <b>San\r\nRafael</b>, cuenta con atractivos <b>naturales</b> como su riqueza hídrica, paisajística\r\ny floral, siendo una de las principales <b>reservas</b> de agua del Sumapaz y\r\nde recarga para humedales, además de poder contar con un bosque montañoso húmedo\r\ny de niebla.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">El recorrido por el sendero natural tiene\r\nuna distancia de <b>4.5</b> kilómetros, donde comprende alturas entre los <b>2100</b>\r\nmsnm y <b>3050</b> msnm, la duración aproximada ida y vuelta por el sendero es\r\nde al menos unas <b>4</b> horas, donde se pueden observar diferentes <b>atractivos</b>\r\npropios del parque como: la palma boba, la aula ambiental, el paso entre rocas,\r\nel puente colonia, el torrente del rio Blanco y la cascada de los deseos.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">Algunas <b>actividades</b> que se pueden practicar\r\nen esta reserva son: fotografía, caminata, senderismo, escalada, avistamiento\r\nde aves y exploración de fauna, cabe recalcar que algunas de estas actividades\r\nsolo pueden ser llevadas a cabo por <b>guías</b> turísticos autorizados por la\r\nciudad de Fusagasugá, además de contar con el equipo deportivo <b>pertinente</b>.<o:p></o:p></span></p>","2020-07-09 19:00:00",1,"2020-07-01 14:04:20","2020-07-01 14:11:10",4,"15936306701.jpg","15936306702.jpg","15936306703.jpg","15936306704.jpg","15936306705.jpg","15936306706.jpg",NULL,NULL,"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.1211026991296!2d-74.32681323570662!3d4.38842334550917!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f05f9c20b56fb%3A0x6ebbef484177422d!2sParque%20San%20Rafael!5e0!3m2!1ses!2sco!4v1592670872596!5m2!1ses!2sco",NULL,"4_Escena"),
(19,"Sendero ecológico al Cerro Fusacatan","sendero-ecologico-al-cerro-fusacatan","1593630960IMG_20200618_073715.webp","El cerro Fusacatan cuenta con diversas estructuras montañosas y de vegetación de gran importancia para el municipio, por el cual circulan 5 quebradas y afluyentes hídricos que lo convierten en un recurso vital para la preservación de fauna y flora en la región.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">El cerro Fusacatan cuenta con diversas <b>estructuras</b>\r\nmontañosas y de vegetación de gran importancia para el municipio, por el cual\r\ncirculan <b>5</b> quebradas y afluyentes hídricos que lo convierten en un recurso\r\n<b>vital</b> para la preservación de <b>fauna</b> y <b>flora</b> en la región, en\r\nel podremos encontrar áreas de bosques húmedos.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">Algunas <b>actividades</b> que se pueden realizar\r\nson: fotografía, caminata, exploración de flora y fauna entre otras, cabe\r\ndestacar que el transito por este sendero debe ser <b>orientado</b> por los guías\r\nlocales u <b>operadores</b> turísticos autorizados por la Oficina de Turismo de\r\nFusagasugá y la Junta de Acción comunal.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">El sendero ecológico que conduce al cerro Fusacatan\r\nse <b>encuentra</b> ubicado en <b>el km 61 Boquerón con Av. Flores</b> en Fusagasugá\r\na la entrada de la finca tradicional “La María”, cuenta con una distancia de <b>2.3</b>\r\nkm y una altura de <b>2600</b> msnm, la duración del recorrido puede durar\r\naproximadamente <b>2</b> horas.<o:p></o:p></span></p>","2020-07-06 19:00:00",1,"2020-07-01 14:13:17","2020-07-01 14:16:00","3.5","15936309601.jpg","15936309602.jpg","15936309603.jpg","15936309604.jpg",NULL,NULL,NULL,NULL,"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3978.655259594268!2d-74.45446648570656!3d4.287005346300539!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f1d48dc170749%3A0xe8098919975d381a!2sFinca%20la%20maria!5e0!3m2!1ses!2sco!4v1592671306181!5m2!1ses!2sco",NULL,"3_Escena"),
(20,"Plazoleta Mayor","plazoleta-mayor","1596813683Plaza_Caratula.webp","Es importante destacar que \"La Plaza Mayor o la Plaza Central\" ha sido el principal escenario de las actividades festivas, como procesiones, misas, bailes y música, desde el periodo colonial.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">A partir del martes <b>7</b> de mayo de <b>1776</b>,\r\nfecha en la que se comisionó a Don Ignacio Pérez de la Cadena para ejecutoriar\r\nla orden real del emperador <b>Carlos lll </b>de fundar el pueblo de <b>Blancos</b>\r\nde Fusagasugá, acto manifiesto que determinó el trazado del nuevo poblamiento\r\ncon las implicaciones que ello significaba <b>social</b>, <b>política</b> y <b>urbanísticamente</b>\r\nde acuerdo con la usanza española. <o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">Desde entonces quedó establecido el marco\r\nreferencial de la cuadricula urbana, espacio central urbanístico <b>histórico</b>\r\nde la ciudad, delimitado por las carreras y calles sexta y séptima\r\nrespectivamente, haciendo frente a la parroquia de <b>Nuestra Señora de Belén</b>\r\ny al <b>Centro Administrativo Municipal</b>, llevará por el único nombre \"<b>Plaza\r\nMayor de Fusagasugá</b>\".<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">Es importante destacar que \"La Plaza\r\nMayor o la Plaza Central\" ha sido el principal <b>escenario</b> de las\r\nactividades festivas, como procesiones, misas, bailes y música, desde el\r\nperiodo colonial.(Guía Turistica,2017)<o:p></o:p></span></p>","2020-08-06 19:00:00",4,"2020-08-07 10:13:30","2020-08-07 10:21:23",4,"1596813683Plaza_360.jpg",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1406.5619365589996!2d-74.36272780705977!3d4.3437488814555225!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f7777a3397%3A0x1422933a1b82ca5d!2sParque%20Principal!5e0!3m2!1ses!2sco!4v1596573313706!5m2!1ses!2sco",NULL,"5_Escena"),
(22,"Casa de la Cultura","casa-de-la-cultura","1597154617Cultura_Caratula.webp","La casa de la cultura es el espacio por excelencia donde futuros artistas de la ciudad se han venido forjando, está destinada principalmente para la formación artística de los fusagasugueños.","<p class=\"MsoNormal\"><span lang=\"ES-CO\">La casa de la <b>cultura</b> es el espacio\r\npor excelencia donde futuros <b>artistas</b> de la ciudad se han venido\r\nforjando, está destinada principalmente para la formación artística de los\r\nfusagasugueños y&nbsp; se encuentra ubicada en\r\nla <b>Transversal 9 #14-91</b>.<o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">Su construcción está <b>inspirada</b> en la\r\narquitectura de haciendas de la época de la <b>emancipación</b> económica, sus\r\nmateriales de <b>construcción</b> se forjan de entrepisos de adobe, tabletas de\r\nmadera y <b>ornamentaciones</b> de hierro. <o:p></o:p></span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"ES-CO\">Inicialmente esta vivienda perteneció a la\r\nfamilia <b>Aya Schoeder</b>, a continuación paso a doña Tulia Pinto de Sáenz,\r\nquien la bautizo como la <b>Tulipana</b>. Anteriormente esta residencia era\r\nconocida como Santa Barbara hasta que fue renombrada.<b> <o:p></o:p></b></span></p>","2020-08-07 19:00:00",4,"2020-08-11 09:00:58","2020-08-11 09:03:39","4.5","1597154617Cultura_360.jpg",NULL,NULL,NULL,NULL,NULL,NULL,NULL,"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1989.1939480149922!2d-74.364740071667!3d4.338064299776071!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e3f04f462f54175%3A0xd05a98b24f14ad89!2sCasona%20La%20Tulipana!5e0!3m2!1ses!2sco!4v1596574666291!5m2!1ses!2sco",NULL,"5_Escena");


DROP TABLE IF EXISTS `role_has_permissions`;

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` VALUES (1,"Admin","web","2020-04-19 09:41:29","2020-04-19 09:41:29"),
(2,"User","web","2020-04-19 09:41:29","2020-04-19 09:41:29");


DROP TABLE IF EXISTS `tags`;

CREATE TABLE `tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `urlimg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tags` VALUES (1,"Arte","2020-05-02 14:47:50","2020-06-20 17:32:19","1592692339Icon_Arte.webp"),
(2,"Avistamiento de Aves","2020-05-02 14:47:50","2020-06-20 17:32:48","1592692368Icon_Avistamiento.webp"),
(3,"Caminata","2020-05-02 14:47:50","2020-06-20 17:33:08","1592692388Icon_Caminar.webp"),
(4,"Ciclopaseo","2020-05-02 14:47:50","2020-06-20 17:33:28","1592692408Icon_CicloPaseo.webp"),
(5,"Educación Ambiental","2020-06-20 17:33:44","2020-06-20 17:33:55","1592692435Icon_Educacion.webp"),
(6,"Escalada","2020-06-20 17:34:06","2020-06-20 17:34:16","1592692456Icon_Escalada.webp"),
(7,"Fauna","2020-06-20 17:34:27","2020-06-20 17:34:35","1592692475Icon_Fauna.webp"),
(8,"Flora","2020-06-20 17:34:44","2020-06-20 17:34:55","1592692495Icon_Flora.webp"),
(9,"Fotografia","2020-06-20 17:35:07","2020-06-20 17:35:16","1592692516Icon_Fotografia.webp"),
(10,"Senderismo","2020-06-20 17:35:25","2020-06-20 17:35:33","1592692533Icon_Senderismo.webp");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `avatar` text COLLATE utf8mb4_unicode_ci,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES (1,"Osman Jimenez","osman9812@hotmail.com",NULL,"$2y$10$Ysjf4qki..utVZp4rtaDfOEYYX/nRT4oTCwKhb9WyZs0BLq5ly5Y6",NULL,"2020-05-02 14:47:50","2020-05-31 15:18:23",NULL,"user.webp",NULL,NULL),
(2,"Armando Osman","armando9812@gmail.com",NULL,"$2y$10$MGtqk0gS1BlKs9u0OpCavOlURuJxGt6SH/eCElG7x7ER54YWvZUv2",NULL,"2020-05-03 09:23:24","2020-05-31 15:32:33",NULL,"user.webp",NULL,NULL),
(3,"Osman Jimenez","osman98125@gmail.com",NULL,"$2y$10$.Fbj4mmqmyPg0I2eHwPMRu9ED1.TPl91f6FwRXQ1HM9QabYEKPe8u","gVrswqUIlEO2q6muEt1eEJTPLw1lxcXWbWVJA99VaNuYOwEx0uqxQn0BpKAQ","2020-05-12 08:25:25","2020-08-31 13:05:06","Imposible","1598896895Perfil_(0).webp",NULL,NULL),
(13,"Samuel","samuel9812@gmail.com",NULL,"$2y$10$EtmH2IWkksZCFXFkEMgY1.bttyweGTN364MO.3wsiJ00anhy9yshq",NULL,"2020-06-02 11:39:57","2020-06-02 12:05:12",NULL,"user.webp",NULL,NULL),
(14,"Armando Cortes Jimenez","armando98125@hotmail.com",NULL,"$2y$10$9EOQxRX0DIv1gAsjPURMiufJ202rP7eyITTekLpGSVT9ohGQxSiJ.",NULL,"2020-06-02 13:30:05","2020-06-13 10:36:20","Esta es una prueba","user.webp",NULL,NULL),
(19,"Jimenez","osman98adds125@gmail.com",NULL,"$2y$10$Jr/sb.PkyDouatOTUoYLBuEu13avKsMKjLueZdRWENwIICiwB/nj6",NULL,"2020-06-15 14:48:46","2020-07-10 14:25:41",NULL,"user.webp",NULL,NULL),
(20,"casa","casa9812@gmail.com",NULL,"$2y$10$TpRtvbqWvMKveJiWyMGdhuAptqGx.bS/sNPNAdGaodaeeijzQObI2",NULL,"2020-06-26 09:36:01","2020-06-26 09:36:01",NULL,NULL,NULL,NULL),
(21,"Jimenez","osman98121321235@gmail.com",NULL,"$2y$10$t/eDVH2b260rmIBbofgi6OlRb1risxkL/qGIE6jMmkN2hksskXUvS",NULL,"2020-06-26 09:41:01","2020-06-26 09:41:01",NULL,NULL,NULL,NULL),
(23,"Jimenez","osman9812sadas5@gmail.com",NULL,"$2y$10$5mu0M.7B8vpi8.wYu7M6nuJkom9jDLmLoecF1YY1ZsfDgXLDBwaDi",NULL,"2020-06-26 09:45:59","2020-06-26 09:45:59",NULL,NULL,NULL,NULL),
(24,"Jimenez Cortes SE","osman981sasa25@gmail.com",NULL,"$2y$10$oR6nOGA44gTJbiTZzKyr6uY5nhIeUHe4HTpna3LZfqxRRA8PLGLbO",NULL,"2020-07-10 19:35:18","2020-07-10 19:35:18",NULL,NULL,NULL,NULL),
(25,"Armando","armandito9812@gmail.com",NULL,"$2y$10$LvD1MiLQUc2x8.4FI6Gg5OC4SEfHCiDliiAD9.uijH7sdz0pSr3u2",NULL,"2020-08-12 07:44:36","2020-08-12 07:44:36",NULL,NULL,NULL,NULL),
(26,"Usuario","usuario@gmail.com",NULL,"$2y$10$eLU1Jnh0sAmvI7PgCmrQBe1l.wk2w4iNCF7IhwxGpbfnMdSlMYO9m",NULL,"2020-08-12 08:48:07","2020-08-12 08:50:02","Esta es la descripción","1597240202Usuario.webp",NULL,NULL),
(27,"PaezAndres","paezandriu28@gmail.com",NULL,"$2y$10$UvVlcS8w7jW7Y380bJhUCuIJf06nJ/IZG9RTQE6wzqYKNkvOaCBJ2",NULL,"2020-08-31 13:07:54","2020-08-31 13:28:38","Me gusta capturar el momento y compartirlos con mis amigos y conocidos","1598898241Screenshot_20200831_132233.webp",NULL,NULL);


SET foreign_key_checks = 1;
