<nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          
          <li class="nav-item">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->is('admin') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-home"></i>
              <p>
                Inicio
              </p>
            </a>
          </li>

          <li class="nav-item has-treeview ">
            <a  href="#" class="nav-link <?php echo e(request()->is('admin/posts') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-map-marker-alt"></i>
              <p>
                Lugares
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
            <a href="#" data-toggle="modal" data-target="#exampleModal" class="nav-link <?php echo e(request()->is('admin/create') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-map-marked-alt"></i>
              <p>
                Agregar
              </p>
            </a>
          </li>
              <li class="nav-item">
            <a href="<?php echo e(route('admin.posts.index')); ?>" class="nav-link <?php echo e(request()->is('admin/posts') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-map"></i>
              <p>
                Ver
              </p>
            </a>
          </li>
            </ul>
          </li>
        </ul>
      </nav><?php /**PATH C:\laragon\www\fusaviajes\resources\views/admin/partials/nav.blade.php ENDPATH**/ ?>