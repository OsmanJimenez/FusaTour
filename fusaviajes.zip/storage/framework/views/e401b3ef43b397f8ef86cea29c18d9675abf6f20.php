

<?php $__env->startSection('content'); ?>

    VR

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fusaviajes\resources\views/pages/vr.blade.php ENDPATH**/ ?>