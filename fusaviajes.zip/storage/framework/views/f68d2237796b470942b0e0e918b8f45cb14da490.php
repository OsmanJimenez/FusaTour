

<?php $__env->startSection('content'); ?>

  <div class="container">  
    <div class="section">
      <div class="spacer"></div>

      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row ">
          <div class="col s12 pad-0">        
            <div class="card">

              <div class="card-image">
                <img style="height:200px;" src="../assets/images/slider-13.jpg">
                <span class="card-title"><?php echo e($category->name); ?></span>
                <a href="/categorias/<?php echo e($category->name); ?>" class="btn-floating halfway-fab waves-effect waves-light primary-bg">
                  <i class="mdi mdi-plus">Ver</i>
                </a>
              </div>

              <div class="card-content">
                <p>Donde la magia surge.</p>
              </div>

            </div>
          </div>
        </div>  
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <div class="spacer"></div>
      
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fusaviajes\resources\views/pages/categorias.blade.php ENDPATH**/ ?>