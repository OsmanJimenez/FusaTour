

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="section">
    
            <div class="row ">
                <div class="col s12 pad-0">
                    <h5 class="bot-20 sec-tit  ">¿Que quieres hacer hoy?</h5>                    

                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                        <ul class="collection notifications z-depth-1">
                            <li class="collection-item avatar">                           
                                <div class="notify" >
                                    <div class="col s1 m4 l2">
                                        <span>
                                            <img src="assets/images/user-18.jpg" alt="Dion Vitale" title="Dion Vitale" class="circle">
                                        </span>
                                    </div>

                                    <div class="col s9 m4 l2">                                       
                                        <p><?php echo e($tag->name); ?></p>                                       
                                    </div>

                                    <div class="col s2 m4 l2">
                                        <a href="/actividades/<?php echo e($tag->name); ?>" class="btn waves-effect waves-light bg-primary" type="submit" name="action">
                                            <i class="mdi mdi-autorenew"></i>
                                        </a>
                                    </div>
                                </div>                    
                            </li>
                        </ul> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
                </div>
            </div>
  
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fusaviajes\resources\views/pages/actividades.blade.php ENDPATH**/ ?>