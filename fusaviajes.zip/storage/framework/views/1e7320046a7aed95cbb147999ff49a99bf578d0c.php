

<?php $__env->startSection('content'); ?>
    <h1>Dashboard 2</h1>
    <p>Usuario autenticado:<?php echo e(auth()->user()->name); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fusaviajes\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>