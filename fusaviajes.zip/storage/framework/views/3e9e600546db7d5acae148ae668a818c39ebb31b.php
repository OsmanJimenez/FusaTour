<?php $__env->startSection('content'); ?>

  <div class="carousel carousel-fullscreen carousel-slider home_carousel">

      <div class="carousel-item" href="#one!">
          <div class="bg" style="background-image: url('assets/images/fusa/1.jpg')"></div>
          <div class="item-content center-align white-text">
              <div class="spacer-large"></div>
              <h3>Fusagasuga</h3>
              <h5 class="light white-text">Recorramos este lugar.</h5>
          </div>
      </div>

      <div class="carousel-item" href="#one!">
          <div class="bg" style="background-image: url('assets/images/fusa/2.jpg')"></div>
          <div class="item-content center-align white-text">
              <div class="spacer-large"></div>
              <h3>Fusagasuga</h3>
              <h5 class="light white-text">Recorramos este lugar.</h5>
          </div>
      </div>
    
      <div class="carousel-item" href="#one!">
          <div class="bg" style="background-image: url('assets/images/fusa/3.jpg')"></div>
          <div class="item-content center-align white-text">
              <div class="spacer-large"></div>
              <h3>Fusagasuga</h3>
              <h5 class="light white-text">Recorramos este lugar.</h5>
          </div>
      </div>

      <div class="carousel-item" href="#one!">
          <div class="bg" style="background-image: url('assets/images/fusa/4.jpg')"></div>
          <div class="item-content center-align white-text">
              <div class="spacer-large"></div>
              <h3>Fusagasuga</h3>
              <h5 class="light white-text">Recorramos este lugar.</h5>
          </div>
      </div>

  </div>

  <div class="container">

    <?php if(isset($title)): ?>
      <h3><?php echo e($title); ?></h3>
    <?php endif; ?>

    <div class="section">
      <h5 class="pagetitle">Lugares</h5>
    </div>
        
    <div class="section">

      <div class="row ui-mediabox blogs">

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
          <div class="col s12">

            <div class="blog-img-wrap">
              <a class="img-wrap" href="/blog/<?php echo e($post->url); ?>" data-fancybox="images" data-caption="Web designing at its very best">
                <img class="z-depth-1" style="height:200px; width: 100%;" src="<?php echo e($post->urlimg); ?>">
              </a>
            </div>

            <div class="blog-info">
              <a href="/blog/<?php echo e($post->url); ?>" >
                <h5 class="title"><?php echo e($post->title); ?></h5>
              </a>  

              <span class="small date"><?php echo e($post->published_at->format('M d')); ?></span>

              <span class="small tags">
                <a class="small" 
                  href="<?php echo e(route('categories.show', $post->category)); ?>"
                  ><?php echo e($post->category->name); ?></a>
                  <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="small" href="<?php echo e(route ('actividades.show', $tag)); ?>">#<?php echo e($tag->name); ?></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </span>    

              <p class="bot-0 text"><?php echo e($post->excerpt); ?> </p>      
                  
              <div class="spacer"></div>
              <div class="divider"></div>
              <div class="spacer"></div>
            </div>

          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      
      <div class="spacer"></div>

    </div>

  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fusaviajes\resources\views/welcome.blade.php ENDPATH**/ ?>