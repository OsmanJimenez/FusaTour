

<?php $__env->startSection('meta-title', $post->title); ?>
<?php $__env->startSection('meta-description', $post->excerpt); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="section">
            <div class="row ui-mediabox blogs bot-0">
                
                <div class="col s12">
                    <a class="img-wrap" href="#" data-fancybox="images" data-caption="How to move with your career">
                        <img class="z-depth-1" style="width: 100%;" src="/<?php echo e($post->urlimg); ?>">
                    </a>
                    <h5 class="title"><?php echo e($post->title); ?></h5>
                    <span class="small date"><?php echo e($post->published_at->format('M d')); ?></span>
                    <span class="small tags">
                        <a class="small" href="#!"><?php echo e($post->category->name); ?></a>, 
                        <a class="small" href="#!">
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="small" href="#!">#<?php echo e($tag->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </a>
                    </span>
                    <p class="bot-0 text">
                        <?php echo $post->body; ?>

                    </p>

                    <div class="spacer"></div>
                </div>
        
                <div class="col s12">
                    <div class="col s12 pad-0">
                        <h5 class="bot-20 sec-tit  ">Realidad Virtual </h5>
                        <iframe width="100%" height="280px" 
                            src="https://poly.google.com/view/duS_-Hxto-5/embed?chrome=min" 
                            frameborder="0" 
                            style="border:none;" 
                            allowvr="yes" 
                            allow="vr; xr; accelerometer; magnetometer; gyroscope; autoplay;" 
                            allowfullscreen mozallowfullscreen="true" 
                            webkitallowfullscreen="true" onmousewheel="" >
                        </iframe>
                    </div>
                </div>

                <div class="spacer"></div>
                <div class="divider"></div>

            </div>
        </div>

        <?php if(Auth::guest()): ?>
            <div class="input-field col s12">
                <textarea id="textarea-normal" class="materialize-textarea validate"></textarea>
                <label for="textarea-normal">Por favor inica Sesion</label>
                <span class="helper-text" data-error="Please enter text" data-success=""></span>
            </div>                  
        <?php else: ?>
            <div class="row ">
                <div class="col s12 pad-0"><h5 class="bot-20 sec-tit  ">Califica este Lugar </h5>
                    <div class="row"> 
                        <style>
                            input[type = "radio"]{ 
                                display:none;/*position: absolute;top: -1000em;*/
                            }
                
                            label{ 
                                color:grey;
                            }

                            .clasificacion{
                                direction: rtl;
                                unicode-bidi: bidi-override;
                            }

                            label:hover,
                            label:hover ~ label{
                                color:orange;
                            }

                            input[type = "radio"]:checked ~ label{
                                color:orange;
                            }

                            .estrella label{
                                font-size: 74px;
                            }
                        </style>

                        <form action="<?php echo e(route('create_comment', ['post' => $post->url ])); ?>" method="POST">
                        <?php echo e(csrf_field()); ?> 
                            <div class="input-field col s12 estrella">
                                <p class="clasificacion">
                                <input  name="point" id="radio5" type="radio" name="estrellas" value="5">
                                <label for="radio5">&#9733;</label>
                                <input name="point" id="radio4" type="radio" name="estrellas" value="4">
                                <label for="radio4">&#9733;</label>
                                <input name="point" id="radio3" type="radio" name="estrellas" value="3">
                                <label for="radio3">&#9733;</label>
                                <input name="point" id="radio2" type="radio" name="estrellas" value="2">
                                <label for="radio2">&#9733;</label>
                                <input name="point" id="radio1" type="radio" name="estrellas" value="1">
                                <label for="radio1">&#9733;</label>
                                </p>
                            </div>

                            <div class="input-field col s12">
                                <textarea  name="comment" id="textarea-normal" class="materialize-textarea validate"></textarea>
                                <label for="textarea-normal">Comentario</label>
                                <span class="helper-text" data-error="Please enter text" data-success=""></span>
                            </div>
                            <textarea style="display:none;" name="id_post" for="textarea-normal"><?php echo e($post->id); ?></textarea>

                            <button class="waves-effect waves-light btn bg-primary">Enviar</button>
                        </form>

                    </div>

                    <div class="spacer"></div>

                </div>
            </div> 
        <?php endif; ?>
            <div class="row ">
                <div class="col s12 pad-0"><h5 class="bot-20 sec-tit  ">Comentarios </h5>
                    <div class="row"> 
                    
                        <ul class="collection contacts z-depth-1">
                        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        

                            <li class="collection-item avatar">
                
                                <a href="#" class='chatlink waves-effect'>                  
                                    <img src="assets/images/user-21.jpg" alt="Simona Gotto" title="Simona Gotto" class="circle">
                                    <span class="title"><?php echo e($comment->user->name); ?></span>
                                    <p><?php echo e($comment->text); ?></p>
                                </a>                
                                
                                <div class="secondary-content">
                                    <p><?php echo e($comment->point); ?> <label for="radio1">&#9733;</label></p>
                                </div>
                            </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>

        <div class="spacer"></div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fusaviajes\resources\views/posts/show.blade.php ENDPATH**/ ?>