<?php $__env->startSection('content'); ?>

    <h1>Necesitamos que estes conectado a internet.</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fusaviajes\resources\views/modules/laravelpwa/offline.blade.php ENDPATH**/ ?>