

<?php $__env->startSection('header'); ?>

    <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Publicaciones</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-home"></i>Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.posts.index')); ?>"><i class="fas fa-list-ul"></i>Post</a></li>
                <li class="breadcrumb-item active"><i class="fas fa-map"></i>Crear</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="content">
      <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Agregar un Lugar</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
          <form method="POST" files="true" action="<?php echo e(route('admin.posts.update', $post)); ?>">
            <?php echo e(csrf_field()); ?> <?php echo e(method_field('PUT')); ?>

            <div class="row">
              <div class="col-md-8">

                <div class="form-group">
                    <label>Nombre del Lugar</label>
                    <input name="title" 
                    value="<?php echo e(old('title', $post->title)); ?>"
                    class="form-control" placeholder="Ingresa aqui el nombre del lugar" required >
                </div>

                <div class="form-group">
                  <label>Categoria</label>
                  <select name="category" 
                  class="form-control" style="width: 100%;" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"
                      <?php echo e(old('category', $post->category_id)); ?>

                      ><?php echo e($category->name); ?> </option>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </select>
                </div>

                <div class="form-group">
                    <label>Información</label>
                        <div class="card-body pad">
                            <div class="mb-4">
                                <textarea name="body"
                                class="textarea " placeholder="Información del Lugar" 
                                    style="width: 100%; height: 300px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
                                    <?php echo e(old('body', $post->body)); ?>

                                    </textarea>
                            </div>
                        </div>
                    </div>
                </div>

              <div class="col-md-4">

                <div class="form-group">
                  <label>Fecha de Publicación:</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="far fa-calendar-alt"></i>
                      </span>
                    </div>
                    <input name="published_at" 
                    value="<?php echo e(old('published_at', $post->published_at ? $post->published_at->format('d/m/Y') :
                    null)); ?>" 
                    type="date" class="form-control float-right" required>
                  </div>
                  <!-- /.input group -->
                </div>

                

                <div class="form-group">
                  <label>Etiquetas</label>
                  <select name="tags[]" class="form-control select2" 
                          multiple="multiple" 
                          data-placeholder="Selecciona una o mas Etiquetas" style="width: 100%;" required>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option <?php echo e(collect(old('tags'))); ?> 
                      value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>

                <div class="form-group">
                  <label for="exampleInputFile">Caratula</label>
                      <div class="input-group">
                        <div class="custom-file">
                          <input type="file" class="custom-file-input" id="exampleInputFile">
                          <label class="custom-file-label" for="exampleInputFile">Escoger Imagen</label>
                        </div>
                        <div class="input-group-append">
                          <span class="input-group-text" id="">Subir</span>
                        </div>
                      </div>
                </div>

                <div class="form-group">
                    <label>Extracto del Lugar</label>
                    <textarea rows="4" name="excerpt" 
                    value="<?php echo e(old('excerpt', $post->excerpt)); ?>"
                    class="form-control" placeholder=""><?php echo e(old('excerpt', $post->excerpt)); ?></textarea>
                </div>



                <div class="form-group">
                    <button type="submit" class="btn btn-outline-primary float-right">Agregar</button>
                </div>
                <!-- /.form-group -->
              </div>
              <!-- /.col -->
              
            </div>
          </form>  
            <!-- /.row -->

            
            <!-- /.row -->
          </div>
          <!-- /.card-body -->
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fusaviajes\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>