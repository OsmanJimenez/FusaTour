@extends('layout')

@section('content')

    <h1>Necesitamos que estes conectado a internet.</h1>

@endsection