@extends('layout')

@section('content')

  <div class="carousel carousel-fullscreen carousel-slider home_carousel">

      <div class="carousel-item" href="#one!">
          <div class="bg" style="background-image: url('assets/images/fusa/1.jpg')"></div>
          <div class="item-content center-align white-text">
              <div class="spacer-large"></div>
              <h3>Fusagasuga</h3>
              <h5 class="light white-text">Recorramos este lugar.</h5>
          </div>
      </div>

      <div class="carousel-item" href="#one!">
          <div class="bg" style="background-image: url('assets/images/fusa/2.jpg')"></div>
          <div class="item-content center-align white-text">
              <div class="spacer-large"></div>
              <h3>Fusagasuga</h3>
              <h5 class="light white-text">Recorramos este lugar.</h5>
          </div>
      </div>
    
      <div class="carousel-item" href="#one!">
          <div class="bg" style="background-image: url('assets/images/fusa/3.jpg')"></div>
          <div class="item-content center-align white-text">
              <div class="spacer-large"></div>
              <h3>Fusagasuga</h3>
              <h5 class="light white-text">Recorramos este lugar.</h5>
          </div>
      </div>

      <div class="carousel-item" href="#one!">
          <div class="bg" style="background-image: url('assets/images/fusa/4.jpg')"></div>
          <div class="item-content center-align white-text">
              <div class="spacer-large"></div>
              <h3>Fusagasuga</h3>
              <h5 class="light white-text">Recorramos este lugar.</h5>
          </div>
      </div>

  </div>

  <div class="container">

    @if(isset($title))
      <h3>{{ $title }}</h3>
    @endif

    <div class="section">
      <h5 class="pagetitle">Lugares</h5>
    </div>
        
    <div class="section">

      <div class="row ui-mediabox blogs">

        @foreach ($posts as $post)       
          <div class="col s12">

            <div class="blog-img-wrap">
              <a class="img-wrap" href="/blog/{{ $post->url }}" data-fancybox="images" data-caption="Web designing at its very best">
                <img class="z-depth-1" style="height:200px; width: 100%;" src="{{ $post->urlimg }}">
              </a>
            </div>

            <div class="blog-info">
              <a href="/blog/{{ $post->url }}" >
                <h5 class="title">{{ $post->title }}</h5>
              </a>  

              <span class="small date">{{ $post->published_at->format('M d') }}</span>

              <span class="small tags">
                <a class="small" 
                  href="{{ route('categories.show', $post->category) }}"
                  >{{ $post->category->name }}</a>
                  @foreach ($post->tags as $tag )
                    <a class="small" href="{{ route ('actividades.show', $tag) }}">#{{ $tag->name }}</a>
                  @endforeach
              </span>    

              <p class="bot-0 text">{{ $post->excerpt }} </p>      
                  
              <div class="spacer"></div>
              <div class="divider"></div>
              <div class="spacer"></div>
            </div>

          </div>
        @endforeach

      </div>
      
      <div class="spacer"></div>

    </div>

  </div>

@stop