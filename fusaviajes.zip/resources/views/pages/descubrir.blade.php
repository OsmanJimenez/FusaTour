@extends('layout')

@section('content')

    Descubrir

@endsection