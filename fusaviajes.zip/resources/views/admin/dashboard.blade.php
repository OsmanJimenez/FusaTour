@extends ('admin.layout')

@section('content')
    <h1>Dashboard 2</h1>
    <p>Usuario autenticado:{{ auth()->user()->name }}</p>
@stop