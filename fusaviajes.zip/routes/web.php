<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@home' )->name('pages.inicio');
Route::get('categorias', 'PagesController@categorias' )->name('pages.categorias');
Route::get('descubrir', 'PagesController@descubrir' )->name('pages.descubrir');
Route::get('actividades', 'PagesController@actividades' )->name('pages.actividades');
Route::get('perfil', 'PagesController@perfil' )->name('pages.perfil')->middleware('auth');



Route::get('blog/{post}', 'PostsController@show')->name('posts.show');
Route::get('categorias/{category}', 'CategoriesController@show')->name('categories.show');
Route::get('actividades/{tag}', 'ActividadesController@show')->name('actividades.show');

Auth::routes();


Route::name('create_comment')->post('blog/{post}', 'PostsCommentsController@create');

Route::auth();

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/offline', function (){
    return view('modules/laravelpwa/offline');
});



Route::group([
    'prefix' => 'admin', 
    'namespace' => 'Admin', 
    'middleware' => 'auth'], 
function(){
    Route::get('/', 'AdminController@index')->name('dashboard');
    Route::get('posts', 'PostsController@index' )->name('admin.posts.index');
    Route::get('posts/create', 'PostsController@create' )->name('admin.posts.create');
    Route::post('posts', 'PostsController@store' )->name('admin.posts.store');
    Route::get('posts/{post}', 'PostsController@edit' )->name('admin.posts.edit');
    Route::put('posts/{post}', 'PostsController@update' )->name('admin.posts.update');
    Route::delete('posts/{post}', 'PostsController@destroy' )->name('admin.posts.destroy');

});

